package com.empower.test.service;

public class CandidateService {
	//write the code for adding, deleting, updating candidates
	//write the code to find candidate by id and retrieve all candidates
	
}
