package com.empower.test.controller;

public class CandidateController {
	//complete the GET, GET/id, POST, PUT, DELETE
}
